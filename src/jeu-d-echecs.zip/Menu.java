//package src;

public class Menu {
    public static void main(String[] args) {

        javax.swing.SwingUtilities.invokeLater( new Runnable() {

            public void run() {
                FenetreMenu fm = new FenetreMenu();
            }

        });
    }
}
